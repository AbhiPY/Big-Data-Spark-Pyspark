package com.dataflair.weblogs.analysis.util;

public class ParamUtil 
{
	public static final String DELIMITER_SPACE = " ";
	public static final String DELIMITER_TAB = "\t";
	public static final String DELIMITER_QUESTIONMARK = "?";
	
	public static final String DEFAULT_VALUE_DASH = "-";
	
}
